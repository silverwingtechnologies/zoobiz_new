<?php 
include '../common/objectController.php';

if(isset($_POST) && !empty($_POST) )//it can be $_GET doesn't matter
{

	if (isset($_POST['addCustomData'])) {

		$m->set_data('send_fcm',$send_fcm);
		$m->set_data('share_within_city',$share_within_city);
		$m->set_data('fcm_content',$fcm_content);
		$today= date("Y-m-d H:i:s");
        $m->set_data('created_date',$today);

		$a = array('send_fcm'=>$m->get_data('send_fcm'),
			'share_within_city'=>$m->get_data('share_within_city'),
			'fcm_content'=>$m->get_data('fcm_content'),
			'created_date'=>$m->get_data('created_date') );
		
		$q = $d->insert("custom_settings_master",$a);

		if($q==TRUE) {
            $_SESSION['msg']="FCM Custom Data Inserted";

          $d->insert_log("","0","$_SESSION[zoobiz_admin_id]","$created_by",$_SESSION['msg']);
			header('location:../customSettings');
		} else {
			$_SESSION['msg1']="Something went wrong.";
			header('location:../customSettings');
		}
	} else if (isset($_POST['updateCustomData'])) {
         $m->set_data('fcm_content',$fcm_content);
		 $a = array('fcm_content'=>$m->get_data('fcm_content') );
		 $q = $d->update("custom_settings_master",$a,"custom_id ='$custom_id'");

		if($q==TRUE) {
            $_SESSION['msg']="FCM Custom Data Updated";
             $d->insert_log("","0","$_SESSION[zoobiz_admin_id]","$created_by",$_SESSION['msg']);
			header('location:../customSettings');
		} else {
			$_SESSION['msg1']="Something went wrong.";
			header('location:../customSettings');
		}
	} if (isset($_POST['addWelcomeData'])) {

		 $m->set_data('send_fcm',$send_fcm);
		$m->set_data('fcm_content',$fcm_content);
		$today= date("Y-m-d H:i:s");
        $m->set_data('created_date',$today);

		$a = array( 
			'send_fcm'=>$m->get_data('send_fcm'),
			'flag' => 1, 
			'fcm_content'=>$m->get_data('fcm_content'),
			'created_date'=>$m->get_data('created_date') );
		
		$q = $d->insert("custom_settings_master",$a);

		if($q==TRUE) {
            $_SESSION['msg']="Custom Welcome user message Inserted";

          $d->insert_log("","0","$_SESSION[zoobiz_admin_id]","$created_by",$_SESSION['msg']);
			header('location:../customSettings');
		} else {
			$_SESSION['msg1']="Something went wrong.";
			header('location:../customSettings');
		}
	} else if (isset($_POST['updateWelcomeData'])) {
         $m->set_data('fcm_content', $fcm_content );
		 $a = array('fcm_content'=>$m->get_data('fcm_content') );
		 $q = $d->update("custom_settings_master",$a,"custom_id ='$custom_id' and flag =1 ");

		if($q==TRUE) {
            $_SESSION['msg']="Custom Welcome user message  Updated";
             $d->insert_log("","0","$_SESSION[zoobiz_admin_id]","$created_by",$_SESSION['msg']);
			header('location:../customSettings');
		} else {
			$_SESSION['msg1']="Something went wrong.";
			header('location:../customSettings');
		}
	} else if (isset($_POST['adminNotificationData'])) {


		 //echo "<pre>";print_r($_POST['zoobiz_admin_id']);exit;
		$m->set_data('send_notification','0');
		 	$a = array('send_notification'=>$m->get_data('send_notification') );
		$q = $d->update("zoobiz_admin_master",$a,"admin_mobile != 0");

		for ($p=0; $p <count($_POST['zoobiz_admin_id']) ; $p++) { 

			$zoobiz_admin_id = $_POST['zoobiz_admin_id'][$p];
			$m->set_data('send_notification','1');
		 	$a = array('send_notification'=>$m->get_data('send_notification') );
			 $q = $d->update("zoobiz_admin_master",$a,"zoobiz_admin_id ='$zoobiz_admin_id'");
		}
               

		if($q==TRUE) {
            $_SESSION['msg']="Custom Zoobiz Admin Notification Updated";
             $d->insert_log("","0","$_SESSION[zoobiz_admin_id]","$created_by", $_SESSION['msg']);
			header('location:../customSettings');
		} else {
			$_SESSION['msg1']="Something went wrong.";
			header('location:../customSettings');
		} 
	}

	//31dec2020
	else if (isset($_POST['editSMSConfData'])) {

		 
		$m->set_data('sms_api_link',$sms_api_link);
		$m->set_data('otp_api_link',$otp_api_link);
        $m->set_data('multiple_sms_link',$multiple_sms_link);
		 	$a = array(
		 		'sms_api_link'=>$m->get_data('sms_api_link'),
		 		'otp_api_link'=>$m->get_data('otp_api_link'),
		 		'multiple_sms_link'=>$m->get_data('multiple_sms_link')
		 		 );
		$q = $d->update("zoobiz_settings_master",$a,"setting_id=1");

		 
               

		if($q==TRUE) {
            $_SESSION['msg']="Custom SMS API Configuration Updated";
             $d->insert_log("","0","$_SESSION[zoobiz_admin_id]","$created_by", $_SESSION['msg']);
			header('location:../customSettings');
		} else {
			$_SESSION['msg1']="Something went wrong.";
			header('location:../customSettings');
		} 
	}
	//31dec2020
}
?>